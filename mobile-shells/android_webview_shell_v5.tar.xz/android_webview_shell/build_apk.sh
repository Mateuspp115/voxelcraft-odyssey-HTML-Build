#!/usr/bin/env bash
# ============================================================================
# BUILD DO APK - VoxelCraft: Odyssey (casca Android nativa, sem Rust/Tauri)
#
# Usa so as ferramentas que ja foram enviadas nas rodadas anteriores:
#   - android-sdk (aapt2, para empacotar recursos)
#   - JDK (javac, para compilar o Java)
#   - android platform "android.jar" (para resolver as classes do Android)
#   - d8 (para converter .class -> .dex, formato que o Android executa)
#   - apksigner + uma keystore (para assinar o APK, obrigatorio para instalar)
#
# Ajuste as variaveis abaixo para os caminhos reais onde voce extraiu os
# pacotes que ja me enviou (Build_parte_1.zip, linkavpn_fix_completo.zip,
# libraries_pack_x86_64_ubuntu.zip).
# ============================================================================
set -e

# ---- AJUSTE ESTAS VARIAVEIS PARA OS CAMINHOS REAIS NO SEU AMBIENTE ----
ANDROID_SDK="${ANDROID_SDK:-/caminho/para/android-sdk}"
AAPT2="${AAPT2:-$ANDROID_SDK/build-tools/*/aapt2}"
ANDROID_JAR="${ANDROID_JAR:-$ANDROID_SDK/platforms/android-34/android.jar}"
D8="${D8:-$ANDROID_SDK/build-tools/*/d8}"
APKSIGNER="${APKSIGNER:-$ANDROID_SDK/build-tools/*/apksigner}"
ZIPALIGN="${ZIPALIGN:-$ANDROID_SDK/build-tools/*/zipalign}"
JAVA_HOME="${JAVA_HOME:-/usr/lib/jvm/default-java}"
KEYSTORE="${KEYSTORE:-./voxelcraft-debug.keystore}"
KEYSTORE_PASS="${KEYSTORE_PASS:-android}"
KEY_ALIAS="${KEY_ALIAS:-voxelcraft}"

APP_DIR="app/src/main"
BUILD_DIR="build"
OUT_APK="voxelcraft-odyssey.apk"

echo "== 1. Limpando build anterior =="
rm -rf "$BUILD_DIR"
mkdir -p "$BUILD_DIR/res-compiled" "$BUILD_DIR/classes" "$BUILD_DIR/dex" "$BUILD_DIR/unsigned"

echo "== 2. Gerando keystore de debug (se ainda nao existir) =="
if [ ! -f "$KEYSTORE" ]; then
  "$JAVA_HOME/bin/keytool" -genkeypair -v \
    -keystore "$KEYSTORE" -storepass "$KEYSTORE_PASS" \
    -alias "$KEY_ALIAS" -keypass "$KEYSTORE_PASS" \
    -keyalg RSA -keysize 2048 -validity 10000 \
    -dname "CN=VoxelCraft Dev, OU=Dev, O=VoxelCraft, L=City, S=State, C=BR"
fi

echo "== 3. Compilando recursos (aapt2) =="
find "$APP_DIR/res" -type f | xargs "$AAPT2" compile -o "$BUILD_DIR/res-compiled" --dir "$APP_DIR/res" || \
  "$AAPT2" compile --dir "$APP_DIR/res" -o "$BUILD_DIR/res-compiled"

echo "== 4. Linkando recursos + AndroidManifest.xml -> APK base (sem codigo ainda) =="
"$AAPT2" link \
  -o "$BUILD_DIR/unsigned/base.apk" \
  -I "$ANDROID_JAR" \
  --manifest "$APP_DIR/AndroidManifest.xml" \
  -A "$APP_DIR/assets" \
  --java "$BUILD_DIR/gen" \
  $(find "$BUILD_DIR/res-compiled" -name '*.flat')

echo "== 5. Compilando Java (MainActivity.java + classes geradas pelo aapt2, ex. R.java) =="
find "$APP_DIR/java" "$BUILD_DIR/gen" -name '*.java' > "$BUILD_DIR/sources.txt"
"$JAVA_HOME/bin/javac" \
  -source 11 -target 11 \
  -classpath "$ANDROID_JAR" \
  -d "$BUILD_DIR/classes" \
  @"$BUILD_DIR/sources.txt"

echo "== 6. Convertendo .class -> .dex (d8) =="
find "$BUILD_DIR/classes" -name '*.class' > "$BUILD_DIR/classfiles.txt"
"$D8" --output "$BUILD_DIR/dex" --lib "$ANDROID_JAR" @"$BUILD_DIR/classfiles.txt"

echo "== 7. Injetando classes.dex dentro do APK base =="
cp "$BUILD_DIR/dex/classes.dex" "$BUILD_DIR/unsigned/"
cd "$BUILD_DIR/unsigned"
zip -u base.apk classes.dex
cd - > /dev/null

echo "== 8. Alinhando o APK (zipalign) =="
"$ZIPALIGN" -f -p 4 "$BUILD_DIR/unsigned/base.apk" "$BUILD_DIR/aligned.apk"

echo "== 9. Assinando o APK (apksigner) =="
"$APKSIGNER" sign \
  --ks "$KEYSTORE" --ks-pass "pass:$KEYSTORE_PASS" \
  --ks-key-alias "$KEY_ALIAS" \
  --out "$OUT_APK" \
  "$BUILD_DIR/aligned.apk"

echo ""
echo "== APK gerado: $OUT_APK =="
echo "Instale no celular com: adb install -r $OUT_APK"
echo "(ou copie o arquivo e abra manualmente no celular, permitindo 'instalar de origem desconhecida')"
