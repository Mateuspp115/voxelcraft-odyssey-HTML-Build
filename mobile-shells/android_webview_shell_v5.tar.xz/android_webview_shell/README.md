# Casca Android nativa (sem Rust/Tauri) — VoxelCraft: Odyssey

## Por que esta casca existe

A rota Tauri (Rust) travou porque meu ambiente não tem acesso à internet
para baixar as dependências do Cargo, e não tinha a biblioteca padrão do
Rust para Android. Em vez de esperar isso se resolver, criei um caminho
alternativo que usa **só as ferramentas que você já me enviou** nas
rodadas anteriores (NDK, SDK, `aapt2`, `d8`, `apksigner`) — nenhuma delas
depende de Rust, Cargo, ou crates.io. É Java puro, compilado com o
próprio JDK.

## O que esta casca faz

- Um `WebView` (componente nativo do Android, existe em todo aparelho)
  carrega o HTML do jogo.
- Tela cheia automática, sem perguntar nada (`sensorLandscape` — o mesmo
  método usado pela Unity e Unreal, confirmei isso).
- Pausa/retoma corretamente quando você troca de app ou bloqueia a tela
  (corrige o travamento de áudio no fundo).
- O botão "voltar" do Android fecha menus abertos no jogo antes de sair
  do app de vez.
- Implementa o mesmo esquema de atualização A/B documentado para o Tauri
  (nova versão do HTML vira um arquivo separado, versão anterior vira
  backup automático, nada é sobrescrito direto).

## Reutilização confirmada

Sim — para usar essa casca em outro jogo, ou atualizar o VoxelCraft sem
recompilar o APK inteiro, a única coisa que muda é o arquivo
`app/src/main/assets/index.html`. Todo o resto (Java, Manifest, ícone,
script de build) é genérico. Isso vale tanto para "trocar de jogo"
quanto para o sistema de Atualizações em si — o HTML novo entra, o
Java não muda nada.

## Como gerar o APK

1. Extraia os pacotes que você já me enviou em algum lugar do seu PC:
   - `Build_parte_1.zip` → tem o `android-sdk` e o `android-ndk`
   - `linkavpn_fix_completo.zip` → tem `aapt2_real`, `apksigner_real`,
     `zipalign_real` prontos para uso (só renomeie removendo o `_real`,
     ou aponte o script direto para eles)
   - `ndk_toolchain.zip` + `ndk_toolchain_zip_2.zip` → JDK/Clang, caso
     seu sistema não tenha um JDK completo com `javac`

2. Copie esta pasta (`android_webview_shell/`) para o mesmo PC.

3. Abra `build_apk.sh` e ajuste as variáveis do topo (`ANDROID_SDK`,
   `JAVA_HOME`, etc.) para os caminhos reais de onde você extraiu os
   pacotes acima.

4. Rode:
   ```
   cd android_webview_shell
   bash build_apk.sh
   ```

5. Isso gera `voxelcraft-odyssey.apk`, já assinado, pronto para instalar:
   ```
   adb install -r voxelcraft-odyssey.apk
   ```
   ou copie o arquivo para o celular e abra manualmente (permitindo
   "instalar de fontes desconhecidas" quando o Android pedir).

## O que eu não pude testar

Não tenho um dispositivo Android nem o SDK completo neste ambiente para
compilar e rodar de ponta a ponta — validei a sintaxe de cada arquivo
Java e XML manualmente (balanceamento de chaves, XML bem formado), mas
a primeira compilação real precisa acontecer no seu lado. Se algo falhar
no `build_apk.sh`, me manda a mensagem de erro exata que eu ajusto.

## Sobre o EXE (Windows Desktop)

Esta casca específica é só Android (usa `android.webkit.WebView`, que
não existe no Windows). Para desktop, a rota mais direta continua sendo
Tauri (quando o vendor chegar) — ou, como alternativa igualmente livre
de Rust, dá para usar o WebView2 nativo do Windows 10/11 via um
executável C#/.NET pequeno, no mesmo espírito desta casca Android. Me
avisa se quiser que eu já prepare essa variante também.
