package com.voxelcraft.odyssey;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.bluetooth.BluetoothAdapter;
import android.bluetooth.BluetoothDevice;
import android.bluetooth.BluetoothServerSocket;
import android.bluetooth.BluetoothSocket;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.SharedPreferences;
import android.content.res.Configuration;
import android.net.Uri;
import android.net.nsd.NsdManager;
import android.net.nsd.NsdServiceInfo;
import android.net.wifi.WifiManager;
import android.net.wifi.p2p.WifiP2pConfig;
import android.net.wifi.p2p.WifiP2pDevice;
import android.net.wifi.p2p.WifiP2pDeviceList;
import android.net.wifi.p2p.WifiP2pInfo;
import android.net.wifi.p2p.WifiP2pManager;
import android.os.Build;
import android.os.Bundle;
import android.view.View;
import android.view.WindowManager;
import android.webkit.JavascriptInterface;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceRequest;
import android.webkit.WebResourceResponse;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.FrameLayout;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.net.InetSocketAddress;
import java.net.ServerSocket;
import java.net.Socket;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

/**
 * Casca nativa Android do VoxelCraft: Odyssey.
 *
 * Diferente da rota Tauri (que exige Rust/Cargo/crates.io, indisponiveis
 * no ambiente de build atual), esta casca usa APENAS a API padrao do
 * Android (android.webkit.WebView), presente em todo dispositivo Android
 * desde a API 1. Compilada com javac + d8 + aapt2 + apksigner - nenhuma
 * dessas ferramentas depende de rede ou de um ecossistema de pacotes
 * externo, diferente do Cargo.
 *
 * Mesma logica de atualizacao A/B documentada para a casca Tauri:
 * o HTML do jogo NAO fica fixo dentro do APK. Ele mora num arquivo,
 * dentro da area de dados privada do app, e um "ponteiro" (active_version)
 * em SharedPreferences diz qual arquivo esta ativo agora. Atualizar o jogo
 * significa salvar um novo arquivo e trocar o ponteiro - nunca recompilar
 * o APK.
 */
public class MainActivity extends Activity {

    private WebView webView;
    private static final String PREFS_NAME = "voxelcraft_prefs";
    private static final String KEY_ACTIVE_VERSION = "active_version_file";
    private static final String KEY_PREVIOUS_VERSION = "previous_version_file";
    private static final String VERSIONS_SUBDIR = "voxelcraft_versions";
    private static final String BUNDLED_ASSET_NAME = "index.html";
    private static final String VIRTUAL_HOST = "appassets.androidplatform.net";

    @Override
    @SuppressLint("SetJavaScriptEnabled")
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        applyImmersiveFullscreen();

        // Pede a permissao de CAMERA do Android logo no inicio (uma vez so, o
        // sistema lembra a resposta). Sem isso, mesmo com o WebView disposto a
        // conceder (ver onPermissionRequest abaixo), a leitura de QR nunca
        // funcionaria de verdade - a permissao do WebView e uma CAMADA A MAIS
        // sobre a permissao do Android, nunca um substituto dela.
        List<String> perms = new ArrayList<>();
        if (!hasPermission(android.Manifest.permission.CAMERA)) perms.add(android.Manifest.permission.CAMERA);
        // Descoberta de jogadores por perto (NSD/Bluetooth) - pedidas juntas pra
        // nao interromper o jogador com varios popups em momentos diferentes.
        if (Build.VERSION.SDK_INT >= 31) {
            if (!hasPermission(android.Manifest.permission.BLUETOOTH_SCAN)) perms.add(android.Manifest.permission.BLUETOOTH_SCAN);
            if (!hasPermission(android.Manifest.permission.BLUETOOTH_ADVERTISE)) perms.add(android.Manifest.permission.BLUETOOTH_ADVERTISE);
            if (!hasPermission(android.Manifest.permission.BLUETOOTH_CONNECT)) perms.add(android.Manifest.permission.BLUETOOTH_CONNECT);
        } else {
            if (!hasPermission(android.Manifest.permission.ACCESS_FINE_LOCATION)) perms.add(android.Manifest.permission.ACCESS_FINE_LOCATION);
        }
        // Wi-Fi Direct sempre pede localizacao fina, em qualquer versao (regra do
        // proprio Android, nao e escolha do app) - ja garantido pelo bloco acima
        // na versao antiga; na versao nova o P2P ainda depende dela na pratica.
        if (Build.VERSION.SDK_INT >= 31 && !hasPermission(android.Manifest.permission.ACCESS_FINE_LOCATION)) {
            perms.add(android.Manifest.permission.ACCESS_FINE_LOCATION);
        }
        // Ponto de acesso local (hotspot sem internet) - Android 13+ usa esta em vez de localizacao.
        if (Build.VERSION.SDK_INT >= 33 && !hasPermission("android.permission.NEARBY_WIFI_DEVICES")) {
            perms.add("android.permission.NEARBY_WIFI_DEVICES");
        }
        if (!perms.isEmpty()) requestPermissions(perms.toArray(new String[0]), 1001);

        webView = new WebView(this);
        setContentView(webView);

        WebSettings settings = webView.getSettings();
        settings.setJavaScriptEnabled(true);
        settings.setDomStorageEnabled(true);           // localStorage
        settings.setDatabaseEnabled(true);              // IndexedDB depende disso em versoes antigas
        settings.setMediaPlaybackRequiresUserGesture(true); // mesmo comportamento de navegador para AudioContext
        // file:// desativado de proposito: o HTML agora e servido por uma origem
        // https:// virtual (ver shouldInterceptRequest abaixo), nao por file://.
        // Isso evita o mesmo problema que o proprio Google recomenda evitar
        // (setAllowFileAccess foi marcado como arriscado e depreciado na API 30
        // em favor de servir local com origem http(s)), e tem um beneficio real
        // aqui: file:// NAO e tratado como "secure context" pelo motor, o que
        // bloqueia Service Workers e pode causar problema em APIs perto de
        // WebRTC (usado no multiplayer) - origem https virtual resolve os dois.
        settings.setAllowFileAccess(false);
        settings.setAllowContentAccess(false);
        settings.setCacheMode(WebSettings.LOAD_DEFAULT);
        settings.setMixedContentMode(WebSettings.MIXED_CONTENT_NEVER_ALLOW);

        webView.setWebViewClient(new WebViewClient() {
            @Override
            public boolean shouldOverrideUrlLoading(WebView view, String url) {
                // Mantem toda navegacao dentro do WebView (o jogo e uma pagina unica,
                // nao deveria navegar para fora, mas evita abrir o navegador do sistema
                // por engano em algum link).
                return false;
            }

            // Serve o HTML (versao ativa ou o empacotado em assets/) atraves de uma
            // origem https:// virtual, no mesmo espirito do androidx.webkit
            // WebViewAssetLoader - so que sem adicionar essa biblioteca externa ao
            // build (este projeto nao usa Gradle/dependencias, entao evitar uma
            // dependencia nova que eu nao consigo testar compilar aqui e a escolha
            // mais segura). O resultado pratico e o mesmo: o WebView passa a
            // enxergar o conteudo como "seguro" (https), o que file:// nao permite.
            @Override
            public WebResourceResponse shouldInterceptRequest(WebView view, WebResourceRequest request) {
                Uri url = request.getUrl();
                if (!VIRTUAL_HOST.equals(url.getHost())) return null; // deixa a WebView tratar normalmente
                String path = url.getPath();
                try {
                    InputStream stream;
                    if (path != null && path.startsWith("/versions/")) {
                        File f = new File(versionsDir(), path.substring("/versions/".length()));
                        stream = new FileInputStream(f);
                    } else if (path != null && path.startsWith("/assets/")) {
                        stream = getAssets().open(path.substring("/assets/".length()));
                    } else {
                        return null;
                    }
                    return new WebResourceResponse("text/html", "UTF-8", stream);
                } catch (IOException e) {
                    return null; // deixa cair no tratamento padrao - erro fica visivel, mais facil de depurar
                }
            }
        });

        // ANTES: concedia QUALQUER pedido de permissao da WebView sem checar nada
        // (request.grant(request.getResources())) - risco real por causa do
        // sistema de Mods: qualquer mod rodando na mesma pagina poderia pedir
        // camera/microfone e ganhar sem nenhum aviso adicional ao usuario.
        //
        // AGORA: so concede o que o app pretende suportar de verdade (camera,
        // para o leitor de QR ainda nao implementado), e mesmo assim so se a
        // permissao Android correspondente ja foi concedida ao app - a permissao
        // da WebView e uma CAMADA A MAIS sobre a permissao do sistema, nunca um
        // substituto dela. Microfone continua sempre negado (o jogo nao usa).
        // Quando o leitor de QR for implementado de verdade, adicionar aqui a
        // chamada de requestPermissions(CAMERA) antes deste ponto ser util.
        webView.setWebChromeClient(new WebChromeClient() {
            @Override
            public void onPermissionRequest(final android.webkit.PermissionRequest request) {
                runOnUiThread(() -> {
                    List<String> allowed = new ArrayList<>();
                    for (String res : request.getResources()) {
                        if (android.webkit.PermissionRequest.RESOURCE_VIDEO_CAPTURE.equals(res)
                                && hasPermission(android.Manifest.permission.CAMERA)) {
                            allowed.add(res);
                        }
                    }
                    if (!allowed.isEmpty()) request.grant(allowed.toArray(new String[0]));
                    else request.deny();
                });
            }
        });

        // Ponte JS <-> Java: expõe o equivalente Android de window.VoxelCraftPlatform,
        // com a mesma assinatura de metodo que o lado JS ja espera (install_update,
        // restart_app), assim o HTML nao precisa saber se esta rodando em Tauri,
        // Android nativo, ou so no navegador.
        webView.addJavascriptInterface(new VoxelCraftPlatformBridge(), "VoxelCraftAndroidBridge");

        loadActiveVersion();
    }

    private void applyImmersiveFullscreen() {
        // Tela cheia real (corrige o jogo nao ficar em tela cheia ao entrar no
        // mundo): esconde barra de status e navegacao, e reaplica sempre que o
        // sistema tentar trazer essas barras de volta (comportamento imersivo
        // "sticky", igual jogos nativos).
        getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN, WindowManager.LayoutParams.FLAG_FULLSCREEN);
        View decorView = getWindow().getDecorView();
        final int flags = View.SYSTEM_UI_FLAG_LAYOUT_STABLE
                | View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION
                | View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN
                | View.SYSTEM_UI_FLAG_HIDE_NAVIGATION
                | View.SYSTEM_UI_FLAG_FULLSCREEN
                | View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY;
        decorView.setSystemUiVisibility(flags);
        decorView.setOnSystemUiVisibilityChangeListener(visibility -> {
            if ((visibility & View.SYSTEM_UI_FLAG_FULLSCREEN) == 0) {
                decorView.setSystemUiVisibility(flags);
            }
        });
    }

    @Override
    public void onWindowFocusChanged(boolean hasFocus) {
        super.onWindowFocusChanged(hasFocus);
        if (hasFocus) applyImmersiveFullscreen();
    }

    @Override
    public void onConfigurationChanged(Configuration newConfig) {
        super.onConfigurationChanged(newConfig);
        applyImmersiveFullscreen();
    }

    // ---- Ciclo de vida: pausar/retomar corretamente evita o AudioContext
    // travado apos a tela bloquear ou o app ir para segundo plano (bug real
    // de robustez identificado em versoes anteriores do jogo rodando so no
    // navegador - aqui a casca nativa garante que o JS recebe o aviso). ----
    @Override
    protected void onPause() {
        super.onPause();
        if (webView != null) {
            webView.onPause();
            webView.evaluateJavascript(
                "document.dispatchEvent(new Event('visibilitychange'));", null);
        }
    }

    @Override
    protected void onResume() {
        super.onResume();
        if (webView != null) {
            webView.onResume();
            webView.evaluateJavascript(
                "document.dispatchEvent(new Event('visibilitychange'));" +
                "if (window.SoundFX && SoundFX.resume) SoundFX.resume();", null);
        }
    }

    @Override
    protected void onDestroy() {
        if (webView != null) {
            webView.evaluateJavascript("if (typeof saveCurrentWorld==='function') saveCurrentWorld();", null);
            webView.destroy();
        }
        super.onDestroy();
    }

    @Override
    public void onBackPressed() {
        // Deixa o proprio jogo decidir (ex.: fechar um menu aberto) antes de
        // sair do app - evita perder progresso por voltar sem querer.
        if (webView != null) {
            webView.evaluateJavascript(
                "(function(){ " +
                "  var anyModalOpen = document.querySelector('.modal-open, [id^=modal-]:not(.hidden)');" +
                "  return !!anyModalOpen;" +
                "})();",
                value -> {
                    if ("true".equals(value)) {
                        webView.evaluateJavascript("document.querySelectorAll('[id^=modal-]:not(.hidden)').forEach(m=>m.classList.add('hidden'));", null);
                    } else {
                        runOnUiThread(MainActivity.super::onBackPressed);
                    }
                });
        } else {
            super.onBackPressed();
        }
    }

    // ---- Esquema A/B de atualizacao (mesma logica documentada para Tauri) ----

    private File versionsDir() {
        File dir = new File(getFilesDir(), VERSIONS_SUBDIR);
        if (!dir.exists()) dir.mkdirs();
        return dir;
    }

    private SharedPreferences prefs() {
        return getSharedPreferences(PREFS_NAME, MODE_PRIVATE);
    }

    private void loadActiveVersion() {
        String activeFile = prefs().getString(KEY_ACTIVE_VERSION, null);
        if (activeFile != null) {
            File f = new File(versionsDir(), activeFile);
            if (f.exists()) {
                webView.loadUrl("https://" + VIRTUAL_HOST + "/versions/" + activeFile);
                return;
            }
        }
        // Primeira execucao (ou ponteiro invalido): carrega o HTML empacotado
        // dentro do proprio APK (assets/index.html), o mesmo arquivo que
        // acompanha esta casca no momento da compilacao - servido pela mesma
        // origem https virtual (ver shouldInterceptRequest).
        webView.loadUrl("https://" + VIRTUAL_HOST + "/assets/" + BUNDLED_ASSET_NAME);
    }

    /**
     * Instala uma nova versao do HTML como a versao ATIVA, mantendo a
     * anterior como backup automatico (nunca sobrescreve o arquivo antigo
     * diretamente). Espelha exatamente install_update() do lado Rust/Tauri.
     */
    private boolean installUpdate(String htmlContent) {
        try {
            File dir = versionsDir();
            String newFileName = "voxelcraft_" + System.currentTimeMillis() + ".html";
            File newFile = new File(dir, newFileName);
            try (FileOutputStream fos = new FileOutputStream(newFile)) {
                fos.write(htmlContent.getBytes("UTF-8"));
            }

            String currentActive = prefs().getString(KEY_ACTIVE_VERSION, null);
            SharedPreferences.Editor editor = prefs().edit();
            if (currentActive != null) editor.putString(KEY_PREVIOUS_VERSION, currentActive);
            editor.putString(KEY_ACTIVE_VERSION, newFileName);
            editor.apply();
            return true;
        } catch (IOException e) {
            return false;
        }
    }

    /** Espelha revert_to_previous() do lado Rust/Tauri. */
    private boolean revertToPrevious() {
        String previous = prefs().getString(KEY_PREVIOUS_VERSION, null);
        if (previous == null) return false;
        File f = new File(versionsDir(), previous);
        if (!f.exists()) return false;
        String current = prefs().getString(KEY_ACTIVE_VERSION, null);
        SharedPreferences.Editor editor = prefs().edit();
        editor.putString(KEY_ACTIVE_VERSION, previous);
        if (current != null) editor.putString(KEY_PREVIOUS_VERSION, current);
        editor.apply();
        return true;
    }

    /** Espelha cleanup_old_versions() do lado Rust/Tauri. */
    private int cleanupOldVersions() {
        String active = prefs().getString(KEY_ACTIVE_VERSION, null);
        String previous = prefs().getString(KEY_PREVIOUS_VERSION, null);
        File dir = versionsDir();
        File[] files = dir.listFiles();
        int removed = 0;
        if (files == null) return 0;
        for (File f : files) {
            String name = f.getName();
            boolean keep = name.equals(active) || name.equals(previous);
            if (!keep && f.delete()) removed++;
        }
        return removed;
    }

    private void restartApp() {
        // ANTES: so fechava o processo (finish + exit) - nao relancava nada,
        // o usuario precisava reabrir o app na mao pra ver a versao nova.
        // AGORA: dispara um novo Intent de lancamento antes de sair, entao o
        // app reabre sozinho ja com o onCreate() lendo o ponteiro atualizado.
        Intent relaunch = getPackageManager().getLaunchIntentForPackage(getPackageName());
        if (relaunch != null) {
            relaunch.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP | Intent.FLAG_ACTIVITY_NEW_TASK);
            startActivity(relaunch);
        }
        finish();
        Runtime.getRuntime().exit(0);
    }

    private boolean hasPermission(String permission) {
        return checkSelfPermission(permission) == android.content.pm.PackageManager.PERMISSION_GRANTED;
    }

    // ================================================================
    // DESCOBERTA DE JOGADORES POR PERTO (NSD = mesma Wi-Fi/hotspot, Bluetooth
    // classico = sem rede nenhuma). WiFi Direct fica para uma proxima rodada -
    // e o mais instavel dos tres entre fabricantes/versoes de Android, prefiro
    // entregar os dois mais confiaveis testados/testaveis do que os tres mal
    // testados.
    //
    // FILOSOFIA (importante): isso NAO substitui o WebRTC que ja existe e ja
    // funciona - so AUTOMATIZA a troca do convite/resposta (o mesmo texto que
    // hoje e copiado/colado ou lido por QR). Depois que o texto e trocado, a
    // conexao nativa e descartada e o jogo continua 100% sobre o WebRTC de
    // sempre, sem nenhuma mudanca na logica de sincronizacao que ja existia e
    // ja foi testada. Risco bem menor, reaproveita tudo.
    // ================================================================
    private static final String NSD_SERVICE_TYPE = "_voxelcraft._tcp.";
    private static final UUID GAME_BT_UUID = UUID.fromString("6f9a2b3e-6f3a-4c9e-9a3b-1a2b3c4d5e6f");
    private final ExecutorService discoveryExecutor = Executors.newCachedThreadPool();
    private NsdManager nsdManager;
    private NsdManager.RegistrationListener nsdRegistrationListener;
    private NsdManager.DiscoveryListener nsdDiscoveryListener;
    private BluetoothAdapter bluetoothAdapter;
    private BroadcastReceiver bluetoothReceiver;
    private ServerSocket discoveryServerSocket;
    private BluetoothServerSocket btServerSocket;
    private final Map<String, NsdServiceInfo> foundNsdPeers = new ConcurrentHashMap<>();
    private final Map<String, BluetoothDevice> foundBtPeers = new ConcurrentHashMap<>();

    private void jsCallback(String jsCode) {
        runOnUiThread(() -> webView.evaluateJavascript(jsCode, null));
    }
    private String jsStr(String s) {
        if (s == null) return "null";
        return "'" + s.replace("\\", "\\\\").replace("'", "\\'").replace("\n", "\\n") + "'";
    }

    // ---- Anfitriao: anuncia nos dois meios e espera alguem conectar ----
    private void discoveryStartHosting(String playerName) {
        discoveryStopAll();
        try {
            discoveryServerSocket = new ServerSocket(0); // porta livre escolhida pelo sistema
            int port = discoveryServerSocket.getLocalPort();
            nsdAdvertise(playerName, port);
            discoveryExecutor.submit(() -> acceptLoopNsd(discoveryServerSocket));
        } catch (IOException e) {
            jsCallback("window.dispatchEvent(new CustomEvent('voxelcraft-discovery-error',{detail:" + jsStr("Falha ao abrir soquete: " + e.getMessage()) + "}))");
        }
        bluetoothAdvertise(playerName);
        wifiDirectStart(true);
    }

    private void acceptLoopNsd(ServerSocket server) {
        try {
            while (!server.isClosed()) {
                Socket client = server.accept(); // bloqueia ate alguem conectar
                discoveryExecutor.submit(() -> handleIncomingSignaling(client));
            }
        } catch (IOException ignored) { /* socket fechado de proposito ao parar */ }
    }

    private void handleIncomingSignaling(Socket socket) {
        try {
            socket.setSoTimeout(20000);
            BufferedReader in = new BufferedReader(new InputStreamReader(socket.getInputStream(), StandardCharsets.UTF_8));
            OutputStreamWriter out = new OutputStreamWriter(socket.getOutputStream(), StandardCharsets.UTF_8);
            // Pede pro JS gerar o convite AGORA (reaproveita hostCreateInvite existente) e
            // aguarda a resposta via signalingSendToSocket() antes de escrever.
            final Socket finalSocket = socket;
            pendingSignalingSocket = finalSocket;
            jsCallback("window.dispatchEvent(new CustomEvent('voxelcraft-discovery-client-connected'))");
            // O proprio JS chama Android.sendDiscoverySignalingText(convite) que escreve no socket.
            String answer = in.readLine(); // aguarda a resposta do outro lado
            socket.close();
            if (answer != null) jsCallback("window.dispatchEvent(new CustomEvent('voxelcraft-discovery-answer-received',{detail:" + jsStr(answer) + "}))");
        } catch (IOException e) {
            jsCallback("window.dispatchEvent(new CustomEvent('voxelcraft-discovery-error',{detail:" + jsStr(e.getMessage()) + "}))");
        }
    }
    private volatile Socket pendingSignalingSocket = null;
    private volatile BluetoothSocket pendingBtSocket = null;

    private void nsdAdvertise(String playerName, int port) {
        nsdManager = (NsdManager) getSystemService(Context.NSD_SERVICE);
        NsdServiceInfo info = new NsdServiceInfo();
        info.setServiceName("VoxelCraft-" + playerName + "-" + (int)(Math.random()*9000));
        info.setServiceType(NSD_SERVICE_TYPE);
        info.setPort(port);
        nsdRegistrationListener = new NsdManager.RegistrationListener() {
            @Override public void onServiceRegistered(NsdServiceInfo si) {}
            @Override public void onRegistrationFailed(NsdServiceInfo si, int err) {}
            @Override public void onServiceUnregistered(NsdServiceInfo si) {}
            @Override public void onUnregistrationFailed(NsdServiceInfo si, int err) {}
        };
        try { nsdManager.registerService(info, NsdManager.PROTOCOL_DNS_SD, nsdRegistrationListener); } catch (Exception ignored) {}
    }

    // ---- Descobridor: procura nos dois meios e avisa o JS a cada achado ----
    private void discoveryStartScanning() {
        discoveryStopAll();
        foundNsdPeers.clear(); foundBtPeers.clear(); foundWifiDirectPeers.clear();
        nsdManager = (NsdManager) getSystemService(Context.NSD_SERVICE);
        nsdDiscoveryListener = new NsdManager.DiscoveryListener() {
            @Override public void onDiscoveryStarted(String type) {}
            @Override public void onStartDiscoveryFailed(String type, int err) {}
            @Override public void onStopDiscoveryFailed(String type, int err) {}
            @Override public void onDiscoveryStopped(String type) {}
            @Override public void onServiceFound(NsdServiceInfo si) {
                if (!si.getServiceType().startsWith("_voxelcraft")) return;
                nsdManager.resolveService(si, new NsdManager.ResolveListener() {
                    @Override public void onResolveFailed(NsdServiceInfo s, int err) {}
                    @Override public void onServiceResolved(NsdServiceInfo s) {
                        String id = "nsd:" + s.getServiceName();
                        foundNsdPeers.put(id, s);
                        String name = s.getServiceName().replace("VoxelCraft-", "").replaceAll("-\\d+$", "");
                        jsCallback("window.dispatchEvent(new CustomEvent('voxelcraft-peer-found',{detail:{id:" + jsStr(id) + ",name:" + jsStr(name) + ",method:'wifi'}}))");
                    }
                });
            }
            @Override public void onServiceLost(NsdServiceInfo si) {
                String id = "nsd:" + si.getServiceName();
                foundNsdPeers.remove(id);
                jsCallback("window.dispatchEvent(new CustomEvent('voxelcraft-peer-lost',{detail:" + jsStr(id) + "}))");
            }
        };
        try { nsdManager.discoverServices(NSD_SERVICE_TYPE, NsdManager.PROTOCOL_DNS_SD, nsdDiscoveryListener); } catch (Exception ignored) {}
        bluetoothScan();
        wifiDirectStart(false);
    }

    private void connectToDiscoveredPeer(String peerId) {
        if (peerId.startsWith("wfd:")) {
            wifiDirectConnectTo(peerId);
            return;
        }
        if (peerId.startsWith("nsd:")) {
            NsdServiceInfo s = foundNsdPeers.get(peerId);
            if (s == null) return;
            discoveryExecutor.submit(() -> {
                try {
                    Socket socket = new Socket();
                    socket.connect(new InetSocketAddress(s.getHost(), s.getPort()), 8000);
                    pendingSignalingSocket = socket;
                    BufferedReader in = new BufferedReader(new InputStreamReader(socket.getInputStream(), StandardCharsets.UTF_8));
                    String invite = in.readLine();
                    if (invite != null) jsCallback("window.dispatchEvent(new CustomEvent('voxelcraft-invite-received',{detail:" + jsStr(invite) + "}))");
                    // a resposta e enviada depois via sendDiscoverySignalingText(), que fecha o socket
                } catch (IOException e) {
                    jsCallback("window.dispatchEvent(new CustomEvent('voxelcraft-discovery-error',{detail:" + jsStr(e.getMessage()) + "}))");
                }
            });
        } else if (peerId.startsWith("bt:")) {
            BluetoothDevice dev = foundBtPeers.get(peerId);
            if (dev == null || !hasPermission(android.Manifest.permission.BLUETOOTH_CONNECT)) return;
            discoveryExecutor.submit(() -> {
                try {
                    if (bluetoothAdapter != null) bluetoothAdapter.cancelDiscovery();
                    BluetoothSocket socket = dev.createRfcommSocketToServiceRecord(GAME_BT_UUID);
                    socket.connect();
                    pendingBtSocket = socket;
                    BufferedReader in = new BufferedReader(new InputStreamReader(socket.getInputStream(), StandardCharsets.UTF_8));
                    String invite = in.readLine();
                    if (invite != null) jsCallback("window.dispatchEvent(new CustomEvent('voxelcraft-invite-received',{detail:" + jsStr(invite) + "}))");
                } catch (IOException e) {
                    jsCallback("window.dispatchEvent(new CustomEvent('voxelcraft-discovery-error',{detail:" + jsStr(e.getMessage()) + "}))");
                }
            });
        }
    }

    // Chamado pelo JS depois de gerar o convite (lado anfitriao) ou a resposta
    // (lado que entra) - escreve no socket que estiver pendente e fecha.
    private void sendDiscoverySignalingText(String text) {
        discoveryExecutor.submit(() -> {
            try {
                if (pendingSignalingSocket != null) {
                    OutputStreamWriter out = new OutputStreamWriter(pendingSignalingSocket.getOutputStream(), StandardCharsets.UTF_8);
                    out.write(text + "\n"); out.flush();
                    if (!pendingSignalingSocket.isClosed() && pendingSignalingSocket.isConnected() && text.length() < 200) {
                        // resposta curta do lado cliente -> pode fechar depois de enviar
                    }
                } else if (pendingBtSocket != null) {
                    OutputStreamWriter out = new OutputStreamWriter(pendingBtSocket.getOutputStream(), StandardCharsets.UTF_8);
                    out.write(text + "\n"); out.flush();
                }
            } catch (IOException ignored) {}
        });
    }

    // ---- Bluetooth classico (funciona sem nenhuma rede Wi-Fi) ----
    @SuppressLint("MissingPermission")
    private void bluetoothAdvertise(String playerName) {
        if (!hasPermission(android.Manifest.permission.BLUETOOTH_CONNECT) && Build.VERSION.SDK_INT >= 31) return;
        android.bluetooth.BluetoothManager bm = (android.bluetooth.BluetoothManager) getSystemService(Context.BLUETOOTH_SERVICE);
        bluetoothAdapter = bm != null ? bm.getAdapter() : null;
        if (bluetoothAdapter == null || !bluetoothAdapter.isEnabled()) return;
        discoveryExecutor.submit(() -> {
            try {
                btServerSocket = bluetoothAdapter.listenUsingRfcommWithServiceRecord("VoxelCraft-" + playerName, GAME_BT_UUID);
                while (true) {
                    BluetoothSocket sock = btServerSocket.accept();
                    discoveryExecutor.submit(() -> handleIncomingBtSignaling(sock));
                }
            } catch (IOException ignored) { /* fechado de proposito ao parar, ou bluetooth indisponivel */ }
        });
    }
    private void handleIncomingBtSignaling(BluetoothSocket socket) {
        try {
            pendingBtSocket = socket;
            jsCallback("window.dispatchEvent(new CustomEvent('voxelcraft-discovery-client-connected'))");
            BufferedReader in = new BufferedReader(new InputStreamReader(socket.getInputStream(), StandardCharsets.UTF_8));
            String answer = in.readLine();
            socket.close();
            if (answer != null) jsCallback("window.dispatchEvent(new CustomEvent('voxelcraft-discovery-answer-received',{detail:" + jsStr(answer) + "}))");
        } catch (IOException ignored) {}
    }
    @SuppressLint("MissingPermission")
    private void bluetoothScan() {
        if (!hasPermission(android.Manifest.permission.BLUETOOTH_SCAN) && Build.VERSION.SDK_INT >= 31) return;
        if (!hasPermission(android.Manifest.permission.ACCESS_FINE_LOCATION) && Build.VERSION.SDK_INT < 31) return;
        android.bluetooth.BluetoothManager bm = (android.bluetooth.BluetoothManager) getSystemService(Context.BLUETOOTH_SERVICE);
        bluetoothAdapter = bm != null ? bm.getAdapter() : null;
        if (bluetoothAdapter == null || !bluetoothAdapter.isEnabled()) return;
        bluetoothReceiver = new BroadcastReceiver() {
            @Override public void onReceive(Context ctx, Intent intent) {
                if (!BluetoothDevice.ACTION_FOUND.equals(intent.getAction())) return;
                BluetoothDevice dev = intent.getParcelableExtra(BluetoothDevice.EXTRA_DEVICE);
                if (dev == null || dev.getName() == null || !dev.getName().startsWith("VoxelCraft-")) return;
                String id = "bt:" + dev.getAddress();
                foundBtPeers.put(id, dev);
                String name = dev.getName().replace("VoxelCraft-", "");
                jsCallback("window.dispatchEvent(new CustomEvent('voxelcraft-peer-found',{detail:{id:" + jsStr(id) + ",name:" + jsStr(name) + ",method:'bluetooth'}}))");
            }
        };
        registerReceiver(bluetoothReceiver, new IntentFilter(BluetoothDevice.ACTION_FOUND));
        bluetoothAdapter.startDiscovery();
    }

    // ---- Wi-Fi Direct (funciona sem rede nenhuma, mais lento pra conectar que
    // os outros dois porque o Android mostra um dialogo do PROPRIO SISTEMA
    // pedindo confirmacao - isso e normal, nao e bug, o app nao tem como pular
    // essa etapa). ----
    private WifiP2pManager wifiP2pManager;
    private WifiP2pManager.Channel wifiP2pChannel;
    private BroadcastReceiver wifiP2pReceiver;
    private final Map<String, WifiP2pDevice> foundWifiDirectPeers = new ConcurrentHashMap<>();
    private static final int WIFI_DIRECT_SIGNALING_PORT = 58925; // porta fixa combinada entre os dois lados - evita o problema conhecido de "como o outro lado descobre a porta"
    private boolean wifiDirectIsGroupOwner = false;

    private void wifiDirectStart(boolean asHost) {
        if (!hasPermission(android.Manifest.permission.ACCESS_FINE_LOCATION)) return;
        wifiP2pManager = (WifiP2pManager) getSystemService(Context.WIFI_P2P_SERVICE);
        if (wifiP2pManager == null) return;
        wifiP2pChannel = wifiP2pManager.initialize(this, getMainLooper(), null);
        wifiP2pReceiver = new BroadcastReceiver() {
            @Override public void onReceive(Context ctx, Intent intent) {
                String action = intent.getAction();
                if (WifiP2pManager.WIFI_P2P_PEERS_CHANGED_ACTION.equals(action)) {
                    wifiP2pManager.requestPeers(wifiP2pChannel, peers -> {
                        for (WifiP2pDevice d : peers.getDeviceList()) {
                            if (d.deviceName == null || !d.deviceName.startsWith("VoxelCraft")) continue;
                            String id = "wfd:" + d.deviceAddress;
                            if (foundWifiDirectPeers.containsKey(id)) continue;
                            foundWifiDirectPeers.put(id, d);
                            jsCallback("window.dispatchEvent(new CustomEvent('voxelcraft-peer-found',{detail:{id:" + jsStr(id) + ",name:" + jsStr(d.deviceName) + ",method:'wifidirect'}}))");
                        }
                    });
                } else if (WifiP2pManager.WIFI_P2P_CONNECTION_CHANGED_ACTION.equals(action)) {
                    wifiP2pManager.requestConnectionInfo(wifiP2pChannel, info -> {
                        if (!info.groupFormed) return;
                        wifiDirectIsGroupOwner = info.isGroupOwner;
                        if (info.isGroupOwner) {
                            discoveryExecutor.submit(() -> wifiDirectListenAsOwner());
                        } else if (info.groupOwnerAddress != null) {
                            discoveryExecutor.submit(() -> wifiDirectConnectToOwner(info.groupOwnerAddress.getHostAddress()));
                        }
                    });
                }
            }
        };
        IntentFilter filter = new IntentFilter();
        filter.addAction(WifiP2pManager.WIFI_P2P_PEERS_CHANGED_ACTION);
        filter.addAction(WifiP2pManager.WIFI_P2P_CONNECTION_CHANGED_ACTION);
        registerReceiver(wifiP2pReceiver, filter);
        if (asHost) {
            wifiP2pManager.createGroup(wifiP2pChannel, new WifiP2pManager.ActionListener() {
                @Override public void onSuccess() {}
                @Override public void onFailure(int reason) {}
            });
        } else {
            wifiP2pManager.discoverPeers(wifiP2pChannel, new WifiP2pManager.ActionListener() {
                @Override public void onSuccess() {}
                @Override public void onFailure(int reason) {}
            });
        }
    }
    private void wifiDirectConnectTo(String peerId) {
        WifiP2pDevice dev = foundWifiDirectPeers.get(peerId);
        if (dev == null || wifiP2pManager == null) return;
        WifiP2pConfig config = new WifiP2pConfig();
        config.deviceAddress = dev.deviceAddress;
        // O Android mostra um dialogo proprio do sistema pedindo confirmacao aqui -
        // e assim que o Wi-Fi Direct funciona, o app nao consegue (nem deveria) pular isso.
        wifiP2pManager.connect(wifiP2pChannel, config, new WifiP2pManager.ActionListener() {
            @Override public void onSuccess() {}
            @Override public void onFailure(int reason) {}
        });
    }
    private void wifiDirectListenAsOwner() {
        try (ServerSocket server = new ServerSocket(WIFI_DIRECT_SIGNALING_PORT)) {
            Socket client = server.accept();
            handleIncomingSignaling(client);
        } catch (IOException ignored) {}
    }
    private void wifiDirectConnectToOwner(String ownerIp) {
        try {
            Socket socket = new Socket();
            socket.connect(new InetSocketAddress(ownerIp, WIFI_DIRECT_SIGNALING_PORT), 10000);
            pendingSignalingSocket = socket;
            BufferedReader in = new BufferedReader(new InputStreamReader(socket.getInputStream(), StandardCharsets.UTF_8));
            String invite = in.readLine();
            if (invite != null) jsCallback("window.dispatchEvent(new CustomEvent('voxelcraft-invite-received',{detail:" + jsStr(invite) + "}))");
        } catch (IOException e) {
            jsCallback("window.dispatchEvent(new CustomEvent('voxelcraft-discovery-error',{detail:" + jsStr(e.getMessage()) + "}))");
        }
    }
    private void wifiDirectStop() {
        try { if (wifiP2pReceiver != null) unregisterReceiver(wifiP2pReceiver); } catch (Exception ignored) {}
        try { if (wifiP2pManager != null && wifiP2pChannel != null) wifiP2pManager.removeGroup(wifiP2pChannel, null); } catch (Exception ignored) {}
        wifiP2pReceiver = null;
        foundWifiDirectPeers.clear();
    }

    // ---- Ponto de acesso local sem internet (LocalOnlyHotspot) - cria uma rede
    // Wi-Fi "do nada", sem precisar de roteador nenhum. Depois que o outro
    // aparelho conectar nela, a descoberta por NSD (Wi-Fi normal) ja implementada
    // funciona sozinha - o hotspot so existe pra criar "a mesma rede" quando nao
    // ha nenhuma disponivel. ----
    private WifiManager.LocalOnlyHotspotReservation hotspotReservation;
    private void startLocalHotspot(Runnable onReady, java.util.function.Consumer<String> onError) {
        String permNeeded = Build.VERSION.SDK_INT >= 33 ? "android.permission.NEARBY_WIFI_DEVICES" : android.Manifest.permission.ACCESS_FINE_LOCATION;
        if (!hasPermission(permNeeded)) { onError.accept("Falta permissão (" + permNeeded + ")"); return; }
        WifiManager wm = (WifiManager) getApplicationContext().getSystemService(Context.WIFI_SERVICE);
        if (wm == null) { onError.accept("Wi-Fi indisponível"); return; }
        wm.startLocalOnlyHotspot(new WifiManager.LocalOnlyHotspotCallback() {
            @Override public void onStarted(WifiManager.LocalOnlyHotspotReservation reservation) {
                hotspotReservation = reservation;
                String ssid, password;
                try {
                    // API nova (28+) da a config estruturada; mais antiga so tem o WifiConfiguration cru.
                    android.net.wifi.SoftApConfiguration cfg = reservation.getSoftApConfiguration();
                    ssid = cfg.getSsid(); password = cfg.getPassphrase();
                } catch (Throwable t) {
                    android.net.wifi.WifiConfiguration legacy = reservation.getWifiConfiguration();
                    ssid = legacy != null ? legacy.SSID : "?"; password = legacy != null ? legacy.preSharedKey : "?";
                }
                jsCallback("window.dispatchEvent(new CustomEvent('voxelcraft-hotspot-ready',{detail:{ssid:" + jsStr(ssid) + ",password:" + jsStr(password) + "}}))");
            }
            @Override public void onStopped() { hotspotReservation = null; }
            @Override public void onFailed(int reason) { onError.accept("Falha ao criar ponto de acesso (código " + reason + ")"); }
        }, null);
    }
    private void stopLocalHotspot() {
        try { if (hotspotReservation != null) hotspotReservation.close(); } catch (Exception ignored) {}
        hotspotReservation = null;
    }

    private void discoveryStopAll() {
        wifiDirectStop();
        stopLocalHotspot();
        try { if (nsdRegistrationListener != null) nsdManager.unregisterService(nsdRegistrationListener); } catch (Exception ignored) {}
        try { if (nsdDiscoveryListener != null) nsdManager.stopServiceDiscovery(nsdDiscoveryListener); } catch (Exception ignored) {}
        try { if (discoveryServerSocket != null) discoveryServerSocket.close(); } catch (Exception ignored) {}
        try { if (btServerSocket != null) btServerSocket.close(); } catch (Exception ignored) {}
        try { if (bluetoothReceiver != null) unregisterReceiver(bluetoothReceiver); } catch (Exception ignored) {}
        try { if (bluetoothAdapter != null) bluetoothAdapter.cancelDiscovery(); } catch (Exception ignored) {}
        nsdRegistrationListener = null; nsdDiscoveryListener = null; discoveryServerSocket = null; btServerSocket = null; bluetoothReceiver = null;
        pendingSignalingSocket = null; pendingBtSocket = null;
    }

    /**
     * Ponte exposta ao JavaScript como window.VoxelCraftAndroidBridge.
     * O lado HTML (VoxelCraftPlatform) detecta a presenca desta ponte e usa
     * ela no lugar do fallback de download, exatamente como faz com
     * window.__TAURI__ quando roda dentro da casca Tauri.
     */
    private class VoxelCraftPlatformBridge {
        @JavascriptInterface
        public boolean installUpdate(String htmlContent) {
            return MainActivity.this.installUpdate(htmlContent);
        }

        @JavascriptInterface
        public boolean revertToPrevious() {
            return MainActivity.this.revertToPrevious();
        }

        @JavascriptInterface
        public int cleanupOldVersions() {
            return MainActivity.this.cleanupOldVersions();
        }

        @JavascriptInterface
        public void restartApp() {
            runOnUiThread(MainActivity.this::restartApp);
        }

        @JavascriptInterface
        public String getEnvironmentName() {
            return "android_native";
        }

        @JavascriptInterface
        public void startHostDiscovery(String playerName) {
            discoveryExecutor.submit(() -> MainActivity.this.discoveryStartHosting(playerName));
        }

        @JavascriptInterface
        public void startPeerDiscovery() {
            discoveryExecutor.submit(MainActivity.this::discoveryStartScanning);
        }

        @JavascriptInterface
        public void stopDiscovery() {
            discoveryExecutor.submit(MainActivity.this::discoveryStopAll);
        }

        @JavascriptInterface
        public void connectToDiscoveredPeer(String peerId) {
            MainActivity.this.connectToDiscoveredPeer(peerId);
        }

        @JavascriptInterface
        public void sendDiscoverySignalingText(String text) {
            MainActivity.this.sendDiscoverySignalingText(text);
        }

        @JavascriptInterface
        public void startLocalHotspot() {
            MainActivity.this.startLocalHotspot(
                () -> {},
                (err) -> jsCallback("window.dispatchEvent(new CustomEvent('voxelcraft-discovery-error',{detail:" + jsStr(err) + "}))")
            );
        }

        @JavascriptInterface
        public void stopLocalHotspot() {
            MainActivity.this.stopLocalHotspot();
        }
    }
}
