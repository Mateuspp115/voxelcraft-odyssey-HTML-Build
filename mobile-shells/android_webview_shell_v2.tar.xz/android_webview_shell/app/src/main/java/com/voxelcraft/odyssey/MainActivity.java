package com.voxelcraft.odyssey;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.res.Configuration;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.view.View;
import android.view.WindowManager;
import android.webkit.JavascriptInterface;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceRequest;
import android.webkit.WebResourceResponse;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.FrameLayout;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.List;

/**
 * Casca nativa Android do VoxelCraft: Odyssey.
 *
 * Diferente da rota Tauri (que exige Rust/Cargo/crates.io, indisponiveis
 * no ambiente de build atual), esta casca usa APENAS a API padrao do
 * Android (android.webkit.WebView), presente em todo dispositivo Android
 * desde a API 1. Compilada com javac + d8 + aapt2 + apksigner - nenhuma
 * dessas ferramentas depende de rede ou de um ecossistema de pacotes
 * externo, diferente do Cargo.
 *
 * Mesma logica de atualizacao A/B documentada para a casca Tauri:
 * o HTML do jogo NAO fica fixo dentro do APK. Ele mora num arquivo,
 * dentro da area de dados privada do app, e um "ponteiro" (active_version)
 * em SharedPreferences diz qual arquivo esta ativo agora. Atualizar o jogo
 * significa salvar um novo arquivo e trocar o ponteiro - nunca recompilar
 * o APK.
 */
public class MainActivity extends Activity {

    private WebView webView;
    private static final String PREFS_NAME = "voxelcraft_prefs";
    private static final String KEY_ACTIVE_VERSION = "active_version_file";
    private static final String KEY_PREVIOUS_VERSION = "previous_version_file";
    private static final String VERSIONS_SUBDIR = "voxelcraft_versions";
    private static final String BUNDLED_ASSET_NAME = "index.html";
    private static final String VIRTUAL_HOST = "appassets.androidplatform.net";

    @Override
    @SuppressLint("SetJavaScriptEnabled")
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        applyImmersiveFullscreen();

        webView = new WebView(this);
        setContentView(webView);

        WebSettings settings = webView.getSettings();
        settings.setJavaScriptEnabled(true);
        settings.setDomStorageEnabled(true);           // localStorage
        settings.setDatabaseEnabled(true);              // IndexedDB depende disso em versoes antigas
        settings.setMediaPlaybackRequiresUserGesture(true); // mesmo comportamento de navegador para AudioContext
        // file:// desativado de proposito: o HTML agora e servido por uma origem
        // https:// virtual (ver shouldInterceptRequest abaixo), nao por file://.
        // Isso evita o mesmo problema que o proprio Google recomenda evitar
        // (setAllowFileAccess foi marcado como arriscado e depreciado na API 30
        // em favor de servir local com origem http(s)), e tem um beneficio real
        // aqui: file:// NAO e tratado como "secure context" pelo motor, o que
        // bloqueia Service Workers e pode causar problema em APIs perto de
        // WebRTC (usado no multiplayer) - origem https virtual resolve os dois.
        settings.setAllowFileAccess(false);
        settings.setAllowContentAccess(false);
        settings.setCacheMode(WebSettings.LOAD_DEFAULT);
        settings.setMixedContentMode(WebSettings.MIXED_CONTENT_NEVER_ALLOW);

        webView.setWebViewClient(new WebViewClient() {
            @Override
            public boolean shouldOverrideUrlLoading(WebView view, String url) {
                // Mantem toda navegacao dentro do WebView (o jogo e uma pagina unica,
                // nao deveria navegar para fora, mas evita abrir o navegador do sistema
                // por engano em algum link).
                return false;
            }

            // Serve o HTML (versao ativa ou o empacotado em assets/) atraves de uma
            // origem https:// virtual, no mesmo espirito do androidx.webkit
            // WebViewAssetLoader - so que sem adicionar essa biblioteca externa ao
            // build (este projeto nao usa Gradle/dependencias, entao evitar uma
            // dependencia nova que eu nao consigo testar compilar aqui e a escolha
            // mais segura). O resultado pratico e o mesmo: o WebView passa a
            // enxergar o conteudo como "seguro" (https), o que file:// nao permite.
            @Override
            public WebResourceResponse shouldInterceptRequest(WebView view, WebResourceRequest request) {
                Uri url = request.getUrl();
                if (!VIRTUAL_HOST.equals(url.getHost())) return null; // deixa a WebView tratar normalmente
                String path = url.getPath();
                try {
                    InputStream stream;
                    if (path != null && path.startsWith("/versions/")) {
                        File f = new File(versionsDir(), path.substring("/versions/".length()));
                        stream = new FileInputStream(f);
                    } else if (path != null && path.startsWith("/assets/")) {
                        stream = getAssets().open(path.substring("/assets/".length()));
                    } else {
                        return null;
                    }
                    return new WebResourceResponse("text/html", "UTF-8", stream);
                } catch (IOException e) {
                    return null; // deixa cair no tratamento padrao - erro fica visivel, mais facil de depurar
                }
            }
        });

        // ANTES: concedia QUALQUER pedido de permissao da WebView sem checar nada
        // (request.grant(request.getResources())) - risco real por causa do
        // sistema de Mods: qualquer mod rodando na mesma pagina poderia pedir
        // camera/microfone e ganhar sem nenhum aviso adicional ao usuario.
        //
        // AGORA: so concede o que o app pretende suportar de verdade (camera,
        // para o leitor de QR ainda nao implementado), e mesmo assim so se a
        // permissao Android correspondente ja foi concedida ao app - a permissao
        // da WebView e uma CAMADA A MAIS sobre a permissao do sistema, nunca um
        // substituto dela. Microfone continua sempre negado (o jogo nao usa).
        // Quando o leitor de QR for implementado de verdade, adicionar aqui a
        // chamada de requestPermissions(CAMERA) antes deste ponto ser util.
        webView.setWebChromeClient(new WebChromeClient() {
            @Override
            public void onPermissionRequest(final android.webkit.PermissionRequest request) {
                runOnUiThread(() -> {
                    List<String> allowed = new ArrayList<>();
                    for (String res : request.getResources()) {
                        if (android.webkit.PermissionRequest.RESOURCE_VIDEO_CAPTURE.equals(res)
                                && hasPermission(android.Manifest.permission.CAMERA)) {
                            allowed.add(res);
                        }
                    }
                    if (!allowed.isEmpty()) request.grant(allowed.toArray(new String[0]));
                    else request.deny();
                });
            }
        });

        // Ponte JS <-> Java: expõe o equivalente Android de window.VoxelCraftPlatform,
        // com a mesma assinatura de metodo que o lado JS ja espera (install_update,
        // restart_app), assim o HTML nao precisa saber se esta rodando em Tauri,
        // Android nativo, ou so no navegador.
        webView.addJavascriptInterface(new VoxelCraftPlatformBridge(), "VoxelCraftAndroidBridge");

        loadActiveVersion();
    }

    private void applyImmersiveFullscreen() {
        // Tela cheia real (corrige o jogo nao ficar em tela cheia ao entrar no
        // mundo): esconde barra de status e navegacao, e reaplica sempre que o
        // sistema tentar trazer essas barras de volta (comportamento imersivo
        // "sticky", igual jogos nativos).
        getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN, WindowManager.LayoutParams.FLAG_FULLSCREEN);
        View decorView = getWindow().getDecorView();
        final int flags = View.SYSTEM_UI_FLAG_LAYOUT_STABLE
                | View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION
                | View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN
                | View.SYSTEM_UI_FLAG_HIDE_NAVIGATION
                | View.SYSTEM_UI_FLAG_FULLSCREEN
                | View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY;
        decorView.setSystemUiVisibility(flags);
        decorView.setOnSystemUiVisibilityChangeListener(visibility -> {
            if ((visibility & View.SYSTEM_UI_FLAG_FULLSCREEN) == 0) {
                decorView.setSystemUiVisibility(flags);
            }
        });
    }

    @Override
    public void onWindowFocusChanged(boolean hasFocus) {
        super.onWindowFocusChanged(hasFocus);
        if (hasFocus) applyImmersiveFullscreen();
    }

    @Override
    public void onConfigurationChanged(Configuration newConfig) {
        super.onConfigurationChanged(newConfig);
        applyImmersiveFullscreen();
    }

    // ---- Ciclo de vida: pausar/retomar corretamente evita o AudioContext
    // travado apos a tela bloquear ou o app ir para segundo plano (bug real
    // de robustez identificado em versoes anteriores do jogo rodando so no
    // navegador - aqui a casca nativa garante que o JS recebe o aviso). ----
    @Override
    protected void onPause() {
        super.onPause();
        if (webView != null) {
            webView.onPause();
            webView.evaluateJavascript(
                "document.dispatchEvent(new Event('visibilitychange'));", null);
        }
    }

    @Override
    protected void onResume() {
        super.onResume();
        if (webView != null) {
            webView.onResume();
            webView.evaluateJavascript(
                "document.dispatchEvent(new Event('visibilitychange'));" +
                "if (window.SoundFX && SoundFX.resume) SoundFX.resume();", null);
        }
    }

    @Override
    protected void onDestroy() {
        if (webView != null) {
            webView.evaluateJavascript("if (typeof saveCurrentWorld==='function') saveCurrentWorld();", null);
            webView.destroy();
        }
        super.onDestroy();
    }

    @Override
    public void onBackPressed() {
        // Deixa o proprio jogo decidir (ex.: fechar um menu aberto) antes de
        // sair do app - evita perder progresso por voltar sem querer.
        if (webView != null) {
            webView.evaluateJavascript(
                "(function(){ " +
                "  var anyModalOpen = document.querySelector('.modal-open, [id^=modal-]:not(.hidden)');" +
                "  return !!anyModalOpen;" +
                "})();",
                value -> {
                    if ("true".equals(value)) {
                        webView.evaluateJavascript("document.querySelectorAll('[id^=modal-]:not(.hidden)').forEach(m=>m.classList.add('hidden'));", null);
                    } else {
                        runOnUiThread(MainActivity.super::onBackPressed);
                    }
                });
        } else {
            super.onBackPressed();
        }
    }

    // ---- Esquema A/B de atualizacao (mesma logica documentada para Tauri) ----

    private File versionsDir() {
        File dir = new File(getFilesDir(), VERSIONS_SUBDIR);
        if (!dir.exists()) dir.mkdirs();
        return dir;
    }

    private SharedPreferences prefs() {
        return getSharedPreferences(PREFS_NAME, MODE_PRIVATE);
    }

    private void loadActiveVersion() {
        String activeFile = prefs().getString(KEY_ACTIVE_VERSION, null);
        if (activeFile != null) {
            File f = new File(versionsDir(), activeFile);
            if (f.exists()) {
                webView.loadUrl("https://" + VIRTUAL_HOST + "/versions/" + activeFile);
                return;
            }
        }
        // Primeira execucao (ou ponteiro invalido): carrega o HTML empacotado
        // dentro do proprio APK (assets/index.html), o mesmo arquivo que
        // acompanha esta casca no momento da compilacao - servido pela mesma
        // origem https virtual (ver shouldInterceptRequest).
        webView.loadUrl("https://" + VIRTUAL_HOST + "/assets/" + BUNDLED_ASSET_NAME);
    }

    /**
     * Instala uma nova versao do HTML como a versao ATIVA, mantendo a
     * anterior como backup automatico (nunca sobrescreve o arquivo antigo
     * diretamente). Espelha exatamente install_update() do lado Rust/Tauri.
     */
    private boolean installUpdate(String htmlContent) {
        try {
            File dir = versionsDir();
            String newFileName = "voxelcraft_" + System.currentTimeMillis() + ".html";
            File newFile = new File(dir, newFileName);
            try (FileOutputStream fos = new FileOutputStream(newFile)) {
                fos.write(htmlContent.getBytes("UTF-8"));
            }

            String currentActive = prefs().getString(KEY_ACTIVE_VERSION, null);
            SharedPreferences.Editor editor = prefs().edit();
            if (currentActive != null) editor.putString(KEY_PREVIOUS_VERSION, currentActive);
            editor.putString(KEY_ACTIVE_VERSION, newFileName);
            editor.apply();
            return true;
        } catch (IOException e) {
            return false;
        }
    }

    /** Espelha revert_to_previous() do lado Rust/Tauri. */
    private boolean revertToPrevious() {
        String previous = prefs().getString(KEY_PREVIOUS_VERSION, null);
        if (previous == null) return false;
        File f = new File(versionsDir(), previous);
        if (!f.exists()) return false;
        String current = prefs().getString(KEY_ACTIVE_VERSION, null);
        SharedPreferences.Editor editor = prefs().edit();
        editor.putString(KEY_ACTIVE_VERSION, previous);
        if (current != null) editor.putString(KEY_PREVIOUS_VERSION, current);
        editor.apply();
        return true;
    }

    /** Espelha cleanup_old_versions() do lado Rust/Tauri. */
    private int cleanupOldVersions() {
        String active = prefs().getString(KEY_ACTIVE_VERSION, null);
        String previous = prefs().getString(KEY_PREVIOUS_VERSION, null);
        File dir = versionsDir();
        File[] files = dir.listFiles();
        int removed = 0;
        if (files == null) return 0;
        for (File f : files) {
            String name = f.getName();
            boolean keep = name.equals(active) || name.equals(previous);
            if (!keep && f.delete()) removed++;
        }
        return removed;
    }

    private void restartApp() {
        // ANTES: so fechava o processo (finish + exit) - nao relancava nada,
        // o usuario precisava reabrir o app na mao pra ver a versao nova.
        // AGORA: dispara um novo Intent de lancamento antes de sair, entao o
        // app reabre sozinho ja com o onCreate() lendo o ponteiro atualizado.
        Intent relaunch = getPackageManager().getLaunchIntentForPackage(getPackageName());
        if (relaunch != null) {
            relaunch.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP | Intent.FLAG_ACTIVITY_NEW_TASK);
            startActivity(relaunch);
        }
        finish();
        Runtime.getRuntime().exit(0);
    }

    private boolean hasPermission(String permission) {
        return checkSelfPermission(permission) == android.content.pm.PackageManager.PERMISSION_GRANTED;
    }

    /**
     * Ponte exposta ao JavaScript como window.VoxelCraftAndroidBridge.
     * O lado HTML (VoxelCraftPlatform) detecta a presenca desta ponte e usa
     * ela no lugar do fallback de download, exatamente como faz com
     * window.__TAURI__ quando roda dentro da casca Tauri.
     */
    private class VoxelCraftPlatformBridge {
        @JavascriptInterface
        public boolean installUpdate(String htmlContent) {
            return MainActivity.this.installUpdate(htmlContent);
        }

        @JavascriptInterface
        public boolean revertToPrevious() {
            return MainActivity.this.revertToPrevious();
        }

        @JavascriptInterface
        public int cleanupOldVersions() {
            return MainActivity.this.cleanupOldVersions();
        }

        @JavascriptInterface
        public void restartApp() {
            runOnUiThread(MainActivity.this::restartApp);
        }

        @JavascriptInterface
        public String getEnvironmentName() {
            return "android_native";
        }
    }
}
